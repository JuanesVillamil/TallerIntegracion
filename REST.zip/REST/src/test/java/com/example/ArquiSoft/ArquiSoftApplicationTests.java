package com.example.ArquiSoft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArquiSoftApplicationTests {

	@Test
	void contextLoads() {
	}

}
