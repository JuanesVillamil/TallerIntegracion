package com.example.ArquiSoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArquiSoftApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArquiSoftApplication.class, args);
	}

}
